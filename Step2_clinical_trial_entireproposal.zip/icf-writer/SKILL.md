---
name: icf-writer
description: 生成符合中国 GCP 和 ICH E6(R3) 的患者知情同意书（ICF），包含 10 条必备条款，语言通俗易懂。
version: 1.0.0
metadata: {"openclaw": {"emoji": "✍️"}}
---

# 知情同意书撰写 Skill

## 概述
生成结构化的 ICF，涵盖研究背景、流程、风险、获益、补偿、保密、自愿退出等条款，补偿部分仅输出占位符。

## 输入（JSON）
```json
{
  "protocol_metadata": {
    "study_title": "string",
    "study_code": "string",
    "phase": "string",
    "drug_name": "string",
    "sponsor": "string",
    "design_description": "string",
    "screening_duration": "string",
    "treatment_duration": "string",
    "followup_duration": "string",
    "visit_summary": "string"
  },
  "risk_benefit": {
    "potential_benefits": "string（可默认）",
    "known_risks": "string（从方案提取）",
    "alternative_treatments": "string（默认）"
  },
  "compensation": {
    "insurance_info": "【待补充：保险单号】",
    "compensation_details": "【待补充：赔偿标准】"
  },
  "ethics_contact": {
    "ec_name": "【待补充：伦理委员会名称】",
    "ec_phone": "【待补充：电话】"
  },
  "pi_contact": {
    "pi_name": "【待补充：研究者姓名】",
    "pi_phone": "【待补充：电话】",
    "site_address": "【待补充：地址】"
  }
}
```

## 输出（JSON）
```json
{
  "document": {
    "format": "markdown",
    "content": "ICF 完整 Markdown 文本"
  },
  "metadata": {
    "document_set_version": "...",
    "version": "icf-writer/1.0.0",
    "generated_at": "...",
    "clauses_covered": ["研究背景", "流程", "风险", "获益", "替代治疗", "保密", "自愿退出", "补偿", "联系人", "伦理审查"]
  }
}
```

## 工作流
1. 按以下顺序生成 10 个条款段落：
   - 1. 研究背景与目的
   - 2. 试验流程与您的责任
   - 3. 可能的风险与不适
   - 4. 可能的获益
   - 5. 替代治疗方案
   - 6. 保密与数据保护
   - 7. 自愿参与与退出权利
   - 8. 补偿与保险（仅占位符）
   - 9. 联系人信息（占位符）
   - 10. 伦理审查委员会联系（占位符）
2. 使用通俗语言：避免“随机化”而说“像抽签一样分组”；避免“不良事件”而说“身体不适或问题”。
3. 在每个占位符处添加明确的 `【待补充：...】` 标签。
4. 在文档末尾添加签名行：参与者签名、日期；研究者签名、日期。

## 约束条件

### 强制事项
- 必须包含全部 10 条必备条款。
- 补偿条款中禁止出现“放弃权利”“免除责任”等词语。
- 必须包含伦理委员会联系信息占位符。

### 禁止事项
- 禁止省略“替代治疗方案”或“自愿退出不影响常规医疗”。
- 禁止使用超过 20 个字的句子。

### 异常处理
- 若方案中包含高风险干预（如活检），自动插入额外风险说明段落，并提示用户确认。
- 若用户未提供任何风险信息，使用通用表述：“本研究可能引起一些不适或意外，具体风险已由医生详细解释。”

## 初始化
直接根据输入生成 ICF，无需问候。
