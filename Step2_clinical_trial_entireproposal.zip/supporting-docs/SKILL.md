---
name: supporting-docs
description: 生成临床试验周边文档：招募广告、患者日志卡、样本标签模板。
version: 1.0.0
metadata: {"openclaw": {"emoji": "📎"}}
---

# 临床试验周边文档生成 Skill

## 概述
根据方案摘要和 CRF 访视结构，生成三份配套文档。

## 输入（JSON）
```json
{
  "protocol_metadata": {
    "study_title": "string",
    "study_code": "string",
    "indication": "string",
    "inclusion_summary": "string（简版入选标准）",
    "exclusion_summary": "string",
    "visit_schedule_simple": "string（如‘共5次访视，为期24周’）"
  },
  "crf_metadata": {
    "visit_structure": ["访视1", "访视2", ...]
  },
  "icf_metadata": {
    "pi_contact": "【待补充：研究者电话】"
  }
}
```

## 输出（JSON）
```json
{
  "documents": {
    "recruitment_ad": {
      "format": "markdown",
      "content": "招募广告内容"
    },
    "patient_diary": {
      "format": "markdown",
      "content": "患者日志卡模板"
    },
    "sample_labels": {
      "format": "markdown",
      "content": "样本标签模板（表格形式）"
    }
  },
  "metadata": {
    "document_set_version": "...",
    "version": "supporting-docs/1.0.0",
    "generated_at": "..."
  }
}
```

## 工作流

### 1. 生成招募广告
- 标题：研究名称 + “受试者招募”
- 内容：
  - 研究目的简述
  - 入选标准摘要（3-5条）
  - 主要排除标准
  - 参与者获益说明（交通补助等，不得写具体金额）
  - 联系人占位符：`【请填写：研究医生姓名、电话】`
  - 伦理批准声明：“本广告已经 XX 伦理委员会批准”

### 2. 生成患者日志卡
- 根据 `visit_structure` 设计每日/每周记录页。
- 包含列：日期、服药时间、剂量、漏服（是/否）、症状记录（可选）、备注。
- 在每个访视点前提示：“第X周访视前请完成以下记录”。

### 3. 生成样本标签模板
- 以三列表格形式输出：
  ```markdown
  | 受试者编号 | 访视编号 | 样本类型 | 采集日期 | 研究中心编号 |
  |------------|----------|----------|----------|---------------|
  | [ID]       | [VISIT]  | 血/尿/...| [DATE]   | [SITE]        |
  ```
- 提示用户使用 Word 邮件合并功能批量打印。

## 约束条件

### 强制事项
- 招募广告中不得包含“免费治疗”“疗效显著”等夸大词语。
- 日志卡的时间线必须与方案访视对齐。

### 禁止事项
- 禁止在日志卡中要求记录身份证号、家庭住址等敏感信息。

### 异常处理
- 若方案包含多个队列或剂量组，提示用户是否需要定制多版日志卡。

## 初始化
直接根据输入生成三份文档，无需问候。
