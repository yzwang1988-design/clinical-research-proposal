---
name: protocol-writer
description: 根据结构化输入生成符合 ICH E6(R3) 格式的临床研究方案（Protocol）。
version: 1.0.0
metadata: {"openclaw": {"emoji": "📝"}}
---

# 临床研究方案撰写 Skill

## 概述
本技能严格按照 ICH E6(R3) Appendix B 大纲生成 13 章结构的研究方案，输出包含 Markdown 正文和结构化元数据。

## 输入（JSON）
```json
{
  "study_info": {...},
  "design": {...},
  "population": {...},
  "endpoints": {...},
  "schedule": {...},
  "other": {...}
}
```

## 输出（JSON）
```json
{
  "document": {
    "format": "markdown",
    "content": "完整的方案 Markdown 文本"
  },
  "metadata": {
    "document_set_version": "研究代号_V1.0.0",
    "version": "protocol-writer/1.0.0",
    "generated_at": "ISO datetime",
    "structured_data": {
      "visit_schedule": "Markdown 表格字符串",
      "endpoints_structured": {
        "primary": {"definition": "...", "timepoint": "...", "method": "..."},
        "secondary": [{"definition": "...", "timepoint": "..."}]
      },
      "safety_plan": "安全性评估章节摘要"
    }
  }
}
```

## 工作流
1. 读取输入 JSON，验证必填字段（标题、阶段、主要终点等），缺失则返回错误。
2. 按以下 13 章顺序生成内容：
   - 标题页（含版本号、申办方、研究者签名行）
   - 摘要
   - 背景与引言
   - 研究目标与终点
   - 试验设计
   - 研究人群（入选/排除标准）
   - 试验干预
   - 研究程序和时间表（生成访视表格）
   - 安全性与耐受性评估
   - 统计方法
   - 数据监查与质量管理
   - 伦理与法规
   - 附录
3. 对于用户未提供但必需的字段（如样本量计算依据），输出 `【待补充：请统计师提供】`。
4. 自动生成版本号：第1版为 `V1.0`，日期为当前日期。
5. 将访视时间点解析为 Markdown 表格，并同时存入 `structured_data.visit_schedule`。
6. 提取主要终点、次要终点、安全性计划到 `structured_data` 中。

## 约束条件

### 强制事项
- 必须包含伦理声明：“本研究将遵循《赫尔辛基宣言》和 ICH E6(R3) 药物临床试验质量管理规范。”
- 访视表格必须包含列：访视名称、时间窗、执行程序。
- 缺失信息一律使用 `【待补充：描述】`，禁止编造。

### 禁止事项
- 禁止使用模糊词汇（“可能”“大概”）。
- 禁止省略安全性评估项目。

### 异常处理
- 若入选/排除标准少于 2 条，返回错误并要求用户补充。
- 若主要终点定义不明确（缺少测量方法或时间点），要求用户澄清。

## 初始化
直接根据输入生成方案，无需问候。
