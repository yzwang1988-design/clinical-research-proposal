# 临床试验文档生成技能包 (OpenClaw Skill Pack)

这是一个为 OpenClaw 设计的临床试验文档生成技能包，严格遵循 ICH E6(R3) 标准。

## 包含的技能

1. **clinical-trial-docs-coordinator**: 主控技能，负责协调所有子技能。
2. **protocol-writer**: 生成临床研究方案 (Protocol)。
3. **crf-designer**: 设计病例报告表 (CRF)。
4. **icf-writer**: 生成知情同意书 (ICF)。
5. **ib-writer**: 生成研究者手册 (IB) 骨架。
6. **supporting-docs**: 生成招募广告、日志卡等周边文档。

## 安装方法

1. 将 `clinical-trial-skill-pack` 文件夹下的所有内容复制到您的 OpenClaw 技能目录：
   - 如果是全局共享：`~/.openclaw/skills/`
   - 如果是特定工作区：`<workspace>/skills/`

2. 重启 OpenClaw 或等待技能监视器自动刷新。

## 使用说明

直接在 OpenClaw 中输入“帮我生成全套临床试验文档”或“开始写临床研究方案”即可触发主控技能。

## 注意事项

- 本技能包生成的文档包含大量 `【待补充：...】` 占位符，请务必在正式使用前进行人工核对和补充。
- 建议在各技能目录下创建 `references/` 文件夹并放入相关的法规和模板文件以获得更精准的生成效果。
