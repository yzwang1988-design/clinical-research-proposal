---
name: ib-writer
description: 生成研究者手册（IB）骨架，包含非临床、临床、安全性数据汇总等章节，具体数据以占位符呈现。
version: 1.0.0
metadata: {"openclaw": {"emoji": "📖"}}
---

# 研究者手册撰写 Skill

## 概述
提供符合 ICH E6(R3) 的 IB 标准大纲，非临床和人体数据均以占位符形式输出，待用户补充。

## 输入（JSON）
```json
{
  "protocol_metadata": {
    "drug_name": "string",
    "study_code": "string",
    "phase": "string",
    "sponsor": "string",
    "dosage_regimen": "string",
    "safety_plan": "string",
    "indication": "string"
  },
  "nonclinical_data": {
    "pharmacology_summary": "【待补充：药效学摘要】",
    "toxicology_summary": "【待补充：急毒/长毒/生殖毒性摘要】",
    "pk_summary": "【待补充：药代动力学数据】"
  },
  "clinical_data": {
    "previous_human_studies": "【待补充：前期人体研究数据】"
  }
}
```

## 输出（JSON）
```json
{
  "document": {
    "format": "markdown",
    "content": "IB 完整 Markdown"
  },
  "metadata": {
    "document_set_version": "...",
    "version": "ib-writer/1.0.0",
    "generated_at": "...",
    "placeholder_list": ["药效学摘要", "毒理学摘要", "药代动力学数据", "前期人体研究数据"]
  }
}
```

## 工作流
1. 生成封面页（保密声明、版本号、申办方）。
2. 生成目录（占位）。
3. 依次生成以下章节，每节内容均为占位符加简要说明：
   - 摘要
   - 引言
   - 非临床研究（分药理、毒理、药代三个子节）
   - 人体研究（药代、药效、有效性、安全性）
   - 安全性数据汇总（提供表格框架，按系统器官分类）
   - 上市经验（如有，占位符）
   - 风险控制措施
   - 数据概要与研究者指导
4. 在安全性数据汇总部分，生成示例表格：
   ```markdown
   | 系统器官分类 | 常见不良事件 | 发生率 | 严重性 |
   |-------------|-------------|--------|--------|
   | 【待补充】   | 【待补充】   | 【待补充】 | 【待补充】 |
   ```
5. 在文档末尾提示用户：“请提供非临床研究报告或安全性数据摘要，可回复 `/fill_ib` 并粘贴内容，我将帮您填入对应章节。”

## 约束条件

### 强制事项
- 必须包含所有标准章节，不可省略。
- 所有具体数据必须使用占位符，禁止推断 or 编造。

### 禁止事项
- 禁止从方案中推断非临床数据（如推测半衰期）。
- 禁止省略“风险控制措施”章节。

### 异常处理
- 若研究为 I 期首次人体试验，强制输出警告：“请务必提供完整的非临床数据摘要，否则 IB 的安全性评估不完整。”

## 初始化
直接生成 IB 骨架，不要求用户立即提供补充数据。
