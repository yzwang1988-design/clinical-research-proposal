---
name: crf-designer
description: 根据方案信息设计 CRF 表，包含基础字段、AE 页面、CDISC 映射。
version: 1.0.0
metadata: {"openclaw": {"emoji": "📊"}}
---

# CRF 设计 Skill

## 概述
生成结构化的 CRF 页面（Markdown 表格形式），每个字段标注 CDASH 变量名和 SDTM 域，符合 CDISC 标准。

## 输入（JSON）
```json
{
  "protocol_metadata": {
    "visit_schedule": "Markdown 表格或 JSON 数组",
    "endpoints_structured": {
      "primary": {...},
      "secondary": [...]
    },
    "safety_plan": "string",
    "study_phase": "string"
  },
  "study_design": {
    "sample_size": "number",
    "sites_count": "number"
  },
  "population": {
    "inclusion": ["..."],
    "exclusion": ["..."]
  },
  "edc_system": "string（可选，占位符）"
}
```

## 输出（JSON）
```json
{
  "document": {
    "format": "markdown",
    "content": "CRF 的 Markdown 描述，分页面展示字段"
  },
  "metadata": {
    "document_set_version": "...",
    "version": "crf-designer/1.0.0",
    "generated_at": "...",
    "crf_structure": {
      "pages": [
        {
          "page_name": "知情同意记录",
          "fields": [
            {"field_name": "受试者编号", "type": "text", "cdash_var": "SUBJID", "sdtm_domain": "DM"},
            ...
          ]
        },
        ...
      ]
    },
    "sdtm_mapping": "string（汇总映射说明）"
  }
}
```

## 工作流
1. 解析输入中的 `visit_schedule`，提取所有访视名称。
2. 创建以下标准页面：
   - 知情同意记录页（固定字段）
   - 人口学页（年龄、性别、种族等）
   - 入选/排除标准核对页（根据入排列表生成 checkbox）
   - 访视页面（每个访视一张表，包含生命体征、实验室等）
   - 不良事件页（含严重程度、关联性、结局等）
   - 合并用药页
   - 研究完成/提前退出页
3. 根据方案中的主要/次要终点，在对应访视页面添加必要的数据收集字段（如 HbA1c 值、量表评分）。
4. 为每个字段分配 `cdash_var`（参考 CDASH 标准）和 `sdtm_domain`（如 DM、AE、CM、LB）。
5. 以 Markdown 表格形式输出每个页面的字段列表，并在末尾提供 SDTM 映射总表。

## 约束条件

### 强制事项
- 必须包含基础字段：受试者编号、中心编号、访视日期、知情同意日期、完成/退出状态。
- AE 页面必须包含：AE 名称、开始日期、结束日期、严重程度（1-5级）、与药物的关系、是否 SAE、结局。
- 每个字段必须标注 `cdash_var` 和 `sdtm_domain`，不可省略。

### 禁止事项
- 禁止省略任何主要/次要终点的数据收集字段。
- 禁止使用非标准化字段名（如“副作用”）。

### 异常处理
- 若访视时间点超过 10 个，提示用户确认是否需要合并页面。
- 若用户未提供 EDC 系统名称，输出占位符 `【EDC系统：待补充】`。

## 初始化
根据输入直接生成 CRF 结构，无需问候。
